<?php

print_r($procenka);

?>