<?php

class Model_klienti extends CI_Model{
	
	
	//funkcija koja pristapuva do baza i gi zema id-to i imeto i prezimeto na sekoj vraboten od tabelata vraboten vo baza , gi stavam vo 
	//asocijativno pole kade klucot mi e id-to
	//na vraboteniot, a value mi e imeto i prezimeto na vraboteniot i potoa gi vrakam na controller-ot.	
	public function get_vraboteni(){
		
		$this->db->select('id, ime_prezime');
		
		$query = $this->db->get('vraboten');
		
		$result = array();
		
		foreach($query->result() as $row){			
			$result[$row->id] = $row->ime_prezime;
		}
		
		return $result;
	}
	
	
	//funkcija koja gi zema site poprecenosti od baza gi smestuva vo asocijativno pole i gi vraka nazad do kontrolerot.
	public function get_poprecenosti(){
		
		
		$query = $this->db->get('tip_poprecenost');
		
		$result = array();
		
		foreach($query->result() as $row){
			$result[$row->tip_poprecenost] = $row->tip_poprecenost;
		}
		
		return $result;
	}
	
	public function get_obrazovanie(){
		
		$query = $this->db->get('tip_obrazovanie');
		
		$result = array();
		
		foreach($query->result() as $row){
			$result[$row->tip_obrazovanie] = $row->tip_obrazovanie;
		}
		
		return $result;
		
	}
	
	public function get_tipPoseta(){
		$query = $this->db->get('tip_poseta');
		
		$result = array();
		
		foreach($query->result() as $row){
			$result[$row->tip_poseta] = $row->tip_poseta;
		}
		
		return $result;
	}	

	public function get_terapevti(){
		
		$query = $this->db->get('terapevt');
		
		$result = array();
		
		foreach($query->result() as $row){
			//vrednosta na ona sto ke se selektira vo nekoja korisnicka kontrola ke bide
			//id-to na terapevtot, a ke se prikazuva imeto i prezimeto na terapevtot
			$result[$row->id_terapevt] = $row->terapevt_ime_prezime;
		}
		
		return $result;
		
	} 
	
	public function get_terapevti_everything(){
		
		$query = $this->db->get('terapevt');				
		
		$result = array();
		
		$pom = $query->result();
		
		for($i=0;$i<sizeof($pom);$i++){
			
			
			$this->db->select('ime_institucija');
			
			$query_institucija = $this->db->get_where('institucija', array('id_institucija' => $pom[$i]->institucija)); 
			
			//imam eden red, no sakam da go zemam kako posebna promenliva, a ne kako array, pa zatoa go izminuvam
			foreach($query_institucija->result() as $row){
				$ime_institucija = $row->ime_institucija;
			}
			
			//dodavam nov atribut vo stdObject instancata ime_institucija koj za 
			$pom[$i]->ime_institucija = $ime_institucija;
			
			//bidejki zemam cel red od baza, kako rezultat mi se vraka stdObject, instanca od stdClass. 
			//Vsusnost jas vo array-ot result ke imam lista od objekti, koi moze da gi pristapam kako obicen clen vo lista
			//a potoa so upotreba na -> da pristapam i do nekoe svojstvo od samiot objekt, svojstvata se vsusnost
			//redovite od baza. Pr: $result[0]->terapevt_ime_prezime.									
			array_push($result, $pom[$i]);
		}
		
		return $result;
		
	}
	
	public function get_nastavnici(){
		$query = $this->db->get('nastavnik');
		
		$result = array();
		
		foreach($query->result() as $row){
			//vrednosta na ona sto ke se selektira vo nekoja korisnicka kontrola ke bide
			//id-to na terapevtot, a ke se prikazuva imeto i prezimeto na terapevtot
			$result[$row->id_nastavnik] = $row->nastavnik_ime_prezime;
		}
		
		return $result;
	}
	
	public function get_institucii(){
		$query = $this->db->get('institucija');
		
		$result = array();
		
		foreach($query->result() as $row){
			//vrednosta na ona sto ke se selektira vo nekoja korisnicka kontrola ke bide
			//id-to na institucijata, a ke se prikazuva imeto na institucijata
			$result[$row->id_institucija] = $row->ime_institucija;
		}
		
		return $result;
	}
	
	
	//funkcija koja ke primi array koj sodrzi podatoci za klientot i gi dodava vo baza.
	public function dodadi_klient($klient){
		
		if($this->db->insert('klient', $klient)){
			//dokolku uspesno sum dodal vo baza, togas treba da go vratam id-to na novo
			//dodadeniot red, za da mozam da go iskoristam za da dodadam poprecenosti za toj
			//korisnik.
			return $this->db->insert_id();
		}
		else return false;
		
	}
	
	//funkcija vo koja za korisnikot so prosledenoto id gi dodavame site poprecenosti koi gi 
	//ima vo baza.
	public function dodadi_poprecenost($id, $poprecenosti){
		
		$rows = array();
		
		foreach($poprecenosti as $p){
			
			$row = array(
				'klient_id' => $id, 
				'tip_poprecenost' => $p
			);

			array_push($rows, $row);
						
		}
		
		if($this->db->insert_batch('korisnik_poprecenost', $rows)){
			return true;
		}
		
		else return false;
	}


	public function dodadi_procenka($id, $procenka){
		
		$this->db->where('id', $id);
		$this->db->update('klient', $procenka);
		
		if($this->db->affected_rows()>0){
			return true;
		}
		
		else return false;
		
	}

	public function dodadi_terapevt_klient($id, $terapevti){
		$rows = array();
		
		foreach($terapevti as $t){
				
			$row = array(
					'id_klient' => $id,
					'id_terapevt' => $t
			);

			
			array_push($rows, $row);
		
		}
		
		if($this->db->insert_batch('klient_terapevt', $rows)){
			return true;
		}
		
		else return false;
		
	}
	
	public function dodadi_plan($id, $plan){
		
		$this->db->where('id', $id);
		$this->db->update('klient', $plan);
		
		if($this->db->affected_rows()>0){
			return true;
		}
		
		else return false;
	}
	
	
	
	
}

?>