<html>

	<head>
		<meta http-equiv ="Content-Type" content = "text/html" charset ="UTF-8"/>	
		
		
		<script>

			function test(form){
				var ck_motorika = /^[A-Za-zА-Ша-ш ]{3,500}$/;

				var errors = new Array();
				
				var motorika = form.motorika.value;

					
				if(!ck_motorika.test(motorika)){
					errors[errors.length] = "Полето за моторика не е успешно валидирано. Внесувај само букви.";
				}				


				if (errors.length > 0) {
					  reportErrors(errors);
					  return false;
				}
				else{
					alert("Podatocite se uspesno validirani");
				}				
			}

			function reportErrors(errors){
				var msg = "Некои од внесените податоци не се валидни...\n";
				 for (var i = 0; i<errors.length; i++) {
					  var numError = i + 1;
					  msg += "\n" + numError + ". " + errors[i];
				 }
				 alert(msg);
			}


		</script>
		
	</head>
	
	<body>
	<?php 
	
		$motorika = array(
			"name" => "motorika",
			"id" => "motorika",
			"value" => set_value("motorika"),
			"rows" => "7",
			"columns" => "65"
		);
	
	
	?>
		
		<h1>Формулар за проценка</h1>
		
		<br/>
		
		<p><?php echo $errors;?></p>
		
		<h2>Личен профил на корисникот</h2>
		<br/>		
			<?php
			
		$attributes = array('name' => 'form', 'id' => 'form', 'onsubmit' => 'return test(this);', 'class' => 'form');			
		

		//echo form_open('controller_klienti/dodadi_procenka_klient/1', $attributes);
		echo form_open('controller_klienti/dodadi_procenka_klient/2', $attributes);
			echo form_label("Проценката ја прави:	");
			echo form_dropdown('vraboteni', $vraboteni)."		";
			
			//sekogas ke dobiva vrednost na tekoven datum.
			echo form_label("Датум кога е направена проценката: ");
			
			?>
			<input type="text" name="datum_procenka" id="datum_procenka" value="<?php echo $tekovenDatum;?>" readonly="readonly"/>			
			
			<h4>Моторика (горни и долни екстремитети, литерализација, подвижност)</h4>
			
			<textarea name="motorika" id="motorika" rows="7" cols="65"><?php set_value("motorika");?></textarea><br/> <br/>
			<?php //echo form_textarea($motorika)."<br>";?>
			
			<h4>Когнитивни способности (внимание, мислење, помнење, ориентација во време и простор,<br/>
			математички способности)</h4>
			
			<textarea name="kognitivni_spos" id="kognitivni_spos" rows="7" cols="65"></textarea><br/> <br/>
			
			<h4>Говор/комуникација</h4>
			
			<textarea name="govor_komunikacija" id="govor_komunikacija" rows="7" cols="65"></textarea><br/> <br/>
			
			<h4>Писменост</h4>
			
			<textarea name="pismenost" id="pismenost" rows="7" cols="65"></textarea><br/> <br/>
			
			
			<h4>Однесување</h4>
			
			<textarea name="odnesuvanje" id="odnesuvanje" rows="7" cols="65"></textarea><br/> <br/>
			
			
			<h4>Ризици</h4>
			
			<textarea name="rizici" id="rizici" rows="7" cols="65"></textarea><br/> <br/>
			
			<h4>Семејно-срединско опкружување</h4>
			<p><i>(каде живее, со кого, драги личности, од животот, интеракција со врсници, 
			возрасни лица, што најчесто прави дома)</i></p>
							
			<textarea name="opkruzuvanje" id="opkruzucvanje" rows="7" cols="65"></textarea><br/> <br/>
			
			<h4>Интереси</h4>
			<p><i>(што сака да прави најчесто)</i></p>
							
			<textarea name="interesi" id="interesi" rows="7" cols="65"></textarea><br/> <br/>
			
			<h4>Компјутерски вештини</h4>
			<p><i>(дали претходно користел/користела компјутер, за која цел, каде)</i></p>
							
			<textarea name="kompjuterski_vestini" id="kompjuterski_vestini" rows="7" cols="65"></textarea><br/> <br/>						
			
			<h3>Работа со терапевти</h3>
			
			<h4>Терапевт со кој работи: </h4>
			
			<?php 			
			foreach($terapevti as $key => $value){
			
			?>
			<input type="checkbox" name="terapevti[]" value="<?php echo $key;?>" /><?php echo $value;?>
			
			<br/><br/>
			
			<?php }?>
			
			<input type="submit" name="dodadiTerapevt" id="dodadiTerapevt" value="Прегледај/додади терапевт" />
			
			<h4>Наставник со кој работи: </h4>
			
			<?php 					
			foreach($nastavnici as $key => $value){
			
			?>
			<input type="radio" name="nastavnici" id="nastavnici" value="<?php echo $key;?>" /><?php echo $value;?>
			
			<br/><br/>
			
			<?php }?>
			
			<input type="submit" name="vnesiProcenka" id="vnesiProcenka" value="Внеси проценка" />
			
		<?php echo form_close();?>
	</body>
</html>

