<html>

	<head>
	
		<meta http-equiv ="Content-Type" content = "text/html" charset ="UTF-8"/>
	
	</head>

<?php


print_r($podatoci_klient);


?>

</html>