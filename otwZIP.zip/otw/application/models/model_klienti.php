<?php

class Model_klienti extends CI_Model{
	
}

?>